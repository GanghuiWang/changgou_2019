package com.changgou.service;

import com.changgou.goods.pojo.Brand;
import com.github.pagehelper.PageInfo;
import io.swagger.models.auth.In;
import org.springframework.stereotype.Service;

import javax.swing.plaf.basic.BasicRadioButtonMenuItemUI;
import java.util.List;


public interface BrandService {

    /**
     * 查询所有
     */
    List<Brand> findAll();

    /**
     * 通过ID查询
     */
    Brand findById(Integer id);

    /**
     * 增加品牌
     */
    void add(Brand brand);

    /**
     * 根据ID修改品牌
     */
    void update(Brand brand);

    /**
     * 根据ID删除品牌
     */
    void delete(Integer id);

    /**
     * 根据集合信息多条件查询品牌信息
     * @param brand
     */
    List<Brand> findList(Brand brand);

    /**
     * 分页实现
     * @param page:当前页
     * @param size:每页显示多少条
     */
    PageInfo<Brand> findPage(Integer page,Integer size);

    /**
     * 分页实现
     * @param brand:条件
     * @param page:当前页
     * @param size:每页显示多少条
     */
    PageInfo<Brand> findPage(Brand brand,Integer page,Integer size);
}
