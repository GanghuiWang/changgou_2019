package com.changgou.controller;

import com.changgou.goods.pojo.Brand;
import com.changgou.service.BrandService;
import com.github.pagehelper.PageInfo;
import entity.Result;
import entity.StatusCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import controller.BaseExceptionHandler;

import java.util.List;

@RestController
@RequestMapping("/brand")
@CrossOrigin
/**
 * 跨域：a域名访问b域名的数据
 *      域名或者端口或者协议不一致时即跨域
 *      如下例子:
 *      http://www.test.com/ 	    http://www.test.com/index.html 	    否 	    同源（协议、域名、端口号相同）
 *      http://www.test.com/ 	    https://www.test.com/index.html 	跨域 	协议不同（http/https）
 *      http://www.test.com/ 	    http://www.baidu.com/ 	            跨域 	主域名不同（test/baidu）
 *      http://www.test.com/ 	    http://blog.test.com/ 	            跨域 	子域名不同（www/blog）
 *      http://www.test.com:8080/ 	http://www.test.com:7001/ 	        跨域 	端口号不同（8080/7001）
 */
public class BrandController extends BaseExceptionHandler{
    @Autowired
    private BrandService brandService;

    @GetMapping
    public Result<List<Brand>> findAll(){
        List<Brand> brands = brandService.findAll();
        return new Result<List<Brand>>(true, StatusCode.OK, "查询品牌集合成功", brands);
    }
    /**
     * 根据Id查询
     */
    @GetMapping(value="/{id}")
    public Result<Brand> findById(@PathVariable(value="id")Integer id){
        Brand brand = brandService.findById(id);
        return new Result<Brand>(true, StatusCode.OK, "通过id查询品牌成功", brand);
    }

    /**
     * 添加对象
     */
    @PostMapping
    public Result addBrand(@RequestBody Brand brand) {
        brandService.add(brand);
        return new Result(true, StatusCode.OK, "添加品牌信息成功！");
    }

    /**
     * 品牌修改实现
     */
    @PutMapping(value = "/{id}")
    public Result updateBrand(@PathVariable(value = "id") Integer id, @RequestBody Brand brand) {
        brand.setId(id);
        brandService.update(brand);
        return new Result(true, StatusCode.OK, "修改品牌信息成功！");
    }

    /**
     * 品牌删除实现
     */
    @DeleteMapping(value = "/{id}")
    public Result deleteBrand(@PathVariable(value = "id") Integer id) {
        brandService.delete(id);
        return new Result(true, StatusCode.OK, "删除品牌信息成功！");
    }

    /**
     * 条件搜索
     */
    @PostMapping(value = "/search")
    public Result<List<Brand>> findList(@RequestBody Brand brand){
        List<Brand> brands = brandService.findList(brand);
        return new Result(true, StatusCode.OK, "条件查询品牌信息成功！",brands);
    }

    /**
     * 分页查询
     */
    @GetMapping(value = "/search/{page}/{size}")
    public Result<PageInfo<Brand>> findPage(@PathVariable(value = "page") Integer page,
                                    @PathVariable(value = "size") Integer size){
        PageInfo<Brand> pageInfo = brandService.findPage(page, size);
        return new Result<PageInfo<Brand>>(true, StatusCode.OK, "分页查询品牌信息成功！",pageInfo);
    }

    /**
     * 分页查询+条件查询
     */
    @PostMapping(value = "/search/{page}/{size}")
    public Result<PageInfo<Brand>> findPage(@RequestBody Brand brand, @PathVariable(value = "page") Integer page,
                                            @PathVariable(value = "size") Integer size) {
        int i = 10 / 0;
        PageInfo<Brand> pageInfo = brandService.findPage(brand,page, size);
        return new Result<PageInfo<Brand>>(true, StatusCode.OK, "条件查询品牌信息成功！", pageInfo);
    }

}
